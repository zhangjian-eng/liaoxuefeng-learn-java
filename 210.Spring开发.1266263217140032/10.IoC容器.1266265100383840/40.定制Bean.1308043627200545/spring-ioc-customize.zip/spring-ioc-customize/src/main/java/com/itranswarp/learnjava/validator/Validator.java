package com.itranswarp.learnjava.validator;

public interface Validator {

	void validate(String email, String password, String name);
}
