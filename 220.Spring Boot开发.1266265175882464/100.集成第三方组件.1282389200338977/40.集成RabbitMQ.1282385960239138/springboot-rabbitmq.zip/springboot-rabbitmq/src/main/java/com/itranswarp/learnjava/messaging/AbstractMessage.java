package com.itranswarp.learnjava.messaging;

public class AbstractMessage {

	public String email;
	public String name;
	public long timestamp;

}
